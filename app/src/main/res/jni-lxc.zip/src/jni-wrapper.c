#include <jni.h>
#include <string.h>
#include <stdbool.h>

#include <lxc/lxccontainer.h>
#include <lxc/attach_options.h>
#include <lxc/version.h>

#include "lxc-binding.h"
#include "jni-wrapper.h"

JNIEXPORT jstring JNICALL native_getVersion(JNIEnv *env, jobject thisObj) {
    const char *version = lxc_get_version();
    return (*env)->NewStringUTF(env, version);
}

JNIEXPORT jboolean JNICALL native_add_device_node(JNIEnv *env, jobject thisObj, jobject c, jstring src_path, jstring dest_path) {
	const char *srcPath = (*env)->GetStringUTFChars(env, src_path, NULL);
	const char *destPath = (*env)->GetStringUTFChars(env, dest_path, NULL);
	jboolean result = jni_lxc_add_device_node((struct lxc_container*)c, srcPath, destPath);
	(*env)->ReleaseStringUTFChars(env, src_path, srcPath);
	(*env)->ReleaseStringUTFChars(env, dest_path, destPath);
	return result;
}

JNIEXPORT void JNICALL native_clear_config(JNIEnv *env, jobject thisObj, jobject c) {
    jni_lxc_clear_config((struct lxc_container*)c);
}

JNIEXPORT jboolean JNICALL native_clear_config_item(JNIEnv *env, jobject thisObj, jobject c, jstring key) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    jboolean result = jni_lxc_clear_config_item((struct lxc_container*)c, keyStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    return result;
}

JNIEXPORT jboolean JNICALL native_clone(JNIEnv *env, jobject thisObj, jobject c, jstring newname, jstring lxcpath, jint flags, jstring bdevtype) {
    const char *newName = (*env)->GetStringUTFChars(env, newname, NULL);
    const char *lxcPath = (*env)->GetStringUTFChars(env, lxcpath, NULL);
    const char *bdevType = (*env)->GetStringUTFChars(env, bdevtype, NULL);
    jboolean result = jni_lxc_clone((struct lxc_container*)c, newName, lxcPath, flags, bdevType);
    (*env)->ReleaseStringUTFChars(env, newname, newName);
    (*env)->ReleaseStringUTFChars(env, lxcpath, lxcPath);
    (*env)->ReleaseStringUTFChars(env, bdevtype, bdevType);
    return result;
}

JNIEXPORT jboolean JNICALL native_console(JNIEnv *env, jobject thisObj, jobject c, jint ttynum, jint stdinfd, jint stdoutfd, jint stderrfd, jint escape) {
    jboolean result = jni_lxc_console((struct lxc_container*)c, ttynum, stdinfd, stdoutfd, stderrfd, escape);
    return result;
}

JNIEXPORT jboolean JNICALL native_create(JNIEnv *env, jobject thisObj, jobject c, jstring t, jstring bdevtype, jobject specs, jint flags, jobjectArray argv) {
    const char *tStr = (*env)->GetStringUTFChars(env, t, NULL);
    const char *bdevType = (*env)->GetStringUTFChars(env, bdevtype, NULL);
    struct bdev_specs *specsPtr = (struct bdev_specs*)specs;
    jboolean result = jni_lxc_create((struct lxc_container*)c, tStr, bdevType, specsPtr, flags, argv);
    (*env)->ReleaseStringUTFChars(env, t, tStr);
    (*env)->ReleaseStringUTFChars(env, bdevtype, bdevType);
    return result;
}

JNIEXPORT jboolean JNICALL native_defined(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_defined((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_destroy(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_destroy((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_destroy_with_snapshots(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_destroy_with_snapshots((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_freeze(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_freeze((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_load_config(JNIEnv *env, jobject thisObj, jobject c, jstring alt_file) {
    const char *altFile = (*env)->GetStringUTFChars(env, alt_file, NULL);
    jboolean result = jni_lxc_load_config((struct lxc_container*)c, altFile);
    (*env)->ReleaseStringUTFChars(env, alt_file, altFile);
    return result;
}

JNIEXPORT jboolean JNICALL native_may_control(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_may_control((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_reboot(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_reboot((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_remove_device_node(JNIEnv *env, jobject thisObj, jobject c, jstring src_path, jstring dest_path) {
    const char *srcPath = (*env)->GetStringUTFChars(env, src_path, NULL);
    const char *destPath = (*env)->GetStringUTFChars(env, dest_path, NULL);
    jboolean result = jni_lxc_remove_device_node((struct lxc_container*)c, srcPath, destPath);
    (*env)->ReleaseStringUTFChars(env, src_path, srcPath);
    (*env)->ReleaseStringUTFChars(env, dest_path, destPath);
    return result;
}

JNIEXPORT jboolean JNICALL native_rename(JNIEnv *env, jobject thisObj, jobject c, jstring newname) {
    const char *newName = (*env)->GetStringUTFChars(env, newname, NULL);
    jboolean result = jni_lxc_rename((struct lxc_container*)c, newName);
    (*env)->ReleaseStringUTFChars(env, newname, newName);
    return result;
}

JNIEXPORT jboolean JNICALL native_running(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_running((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_save_config(JNIEnv *env, jobject thisObj, jobject c, jstring alt_file) {
    const char *altFile = (*env)->GetStringUTFChars(env, alt_file, NULL);
    jboolean result = jni_lxc_save_config((struct lxc_container*)c, altFile);
    (*env)->ReleaseStringUTFChars(env, alt_file, altFile);
    return result;
}

JNIEXPORT jboolean JNICALL native_set_cgroup_item(JNIEnv *env, jobject thisObj, jobject c, jstring key, jstring value) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    const char *valueStr = (*env)->GetStringUTFChars(env, value, NULL);
    jboolean result = jni_lxc_set_cgroup_item((struct lxc_container*)c, keyStr, valueStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    (*env)->ReleaseStringUTFChars(env, value, valueStr);
    return result;
}

JNIEXPORT jboolean JNICALL native_set_config_item(JNIEnv *env, jobject thisObj, jobject c, jstring key, jstring value) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    const char *valueStr = (*env)->GetStringUTFChars(env, value, NULL);
    jboolean result = jni_lxc_set_config_item((struct lxc_container*)c, keyStr, valueStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    (*env)->ReleaseStringUTFChars(env, value, valueStr);
    return result;
}

JNIEXPORT jboolean JNICALL native_set_config_path(JNIEnv *env, jobject thisObj, jobject c, jstring path) {
    const char *pathStr = (*env)->GetStringUTFChars(env, path, NULL);
    jboolean result = jni_lxc_set_config_path((struct lxc_container*)c, pathStr);
    (*env)->ReleaseStringUTFChars(env, path, pathStr);
    return result;
}

JNIEXPORT jboolean JNICALL native_shutdown(JNIEnv *env, jobject thisObj, jobject c, jint timeout) {
    jboolean result = jni_lxc_shutdown((struct lxc_container*)c, timeout);
    return result;
}

JNIEXPORT jboolean JNICALL native_snapshot_destroy(JNIEnv *env, jobject thisObj, jobject c, jstring snapname) {
    const char *snapName = (*env)->GetStringUTFChars(env, snapname, NULL);
    jboolean result = jni_lxc_snapshot_destroy((struct lxc_container*)c, snapName);
    (*env)->ReleaseStringUTFChars(env, snapname, snapName);
    return result;
}

JNIEXPORT jboolean JNICALL native_snapshot_destroy_all(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_snapshot_destroy_all((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_snapshot_restore(JNIEnv *env, jobject thisObj, jobject c, jstring snapname, jstring newname) {
    const char *snapName = (*env)->GetStringUTFChars(env, snapname, NULL);
    const char *newName = (*env)->GetStringUTFChars(env, newname, NULL);
    jboolean result = jni_lxc_snapshot_restore((struct lxc_container*)c, snapName, newName);
    (*env)->ReleaseStringUTFChars(env, snapname, snapName);
    (*env)->ReleaseStringUTFChars(env, newname, newName);
    return result;
}

JNIEXPORT jboolean JNICALL native_start(JNIEnv *env, jobject thisObj, jobject c, jint useinit, jobjectArray argv) {
    int argc = (*env)->GetArrayLength(env, argv);
    char *argvArray[argc];

    for (int i = 0; i < argc; i++) {
        jstring arg = (jstring)(*env)->GetObjectArrayElement(env, argv, i);
        argvArray[i] = (char*)(*env)->GetStringUTFChars(env, arg, NULL);
    }

    jboolean result = jni_lxc_start((struct lxc_container*)c, useinit, argvArray);

    for (int i = 0; i < argc; i++) {
        (*env)->ReleaseStringUTFChars(env, (jstring)(*env)->GetObjectArrayElement(env, argv, i), argvArray[i]);
    }

    return result;
}

JNIEXPORT jboolean JNICALL native_stop(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_stop((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_unfreeze(JNIEnv *env, jobject thisObj, jobject c) {
    jboolean result = jni_lxc_unfreeze((struct lxc_container*)c);
    return result;
}

JNIEXPORT jboolean JNICALL native_wait(JNIEnv *env, jobject thisObj, jobject c, jstring state, jint timeout) {
    const char *stateStr = (*env)->GetStringUTFChars(env, state, NULL);
    jboolean result = jni_lxc_wait((struct lxc_container*)c, stateStr, timeout);
    (*env)->ReleaseStringUTFChars(env, state, stateStr);
    return result;
}

JNIEXPORT jboolean JNICALL native_want_close_all_fds(JNIEnv *env, jobject thisObj, jobject c, jboolean state) {
    jboolean result = jni_lxc_want_close_all_fds((struct lxc_container*)c, state);
    return result;
}

JNIEXPORT jboolean JNICALL native_want_daemonize(JNIEnv *env, jobject thisObj, jobject c, jboolean state) {
    jboolean result = jni_lxc_want_daemonize((struct lxc_container*)c, state);
    return result;
}

JNIEXPORT jstring JNICALL native_config_file_name(JNIEnv *env, jobject thisObj, jobject c) {
    char *fileName = jni_lxc_config_file_name((struct lxc_container*)c);
    if (fileName == NULL) {
        return NULL;  // Return null if the C function returns NULL
    }
    return (*env)->NewStringUTF(env, fileName);
}

JNIEXPORT jstring JNICALL native_get_cgroup_item(JNIEnv *env, jobject thisObj, jobject c, jstring key) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    char *value = jni_lxc_get_cgroup_item((struct lxc_container*)c, keyStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    if (value == NULL) {
        return NULL;
    }
    return (*env)->NewStringUTF(env, value);
}

JNIEXPORT jstring JNICALL native_get_config_item(JNIEnv *env, jobject thisObj, jobject c, jstring key) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    char *value = jni_lxc_get_config_item((struct lxc_container*)c, keyStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    if (value == NULL) {
        return NULL;
    }
    return (*env)->NewStringUTF(env, value);
}

JNIEXPORT jobjectArray JNICALL native_get_interfaces(JNIEnv *env, jobject thisObj, jobject c) {
    char **interfaces = jni_lxc_get_interfaces((struct lxc_container*)c);
    if (interfaces == NULL) {
        return NULL;
    }

    // Counting the number of interfaces
    int i = 0;
    while (interfaces[i] != NULL) {
        i++;
    }

    // Create a new Java String array of the correct size
    jobjectArray result = (*env)->NewObjectArray(env, i, (*env)->FindClass(env, "java/lang/String"), NULL);

    // Populate the Java String array
    for (int j = 0; j < i; j++) {
        (*env)->SetObjectArrayElement(env, result, j, (*env)->NewStringUTF(env, interfaces[j]));
    }

    return result;
}

JNIEXPORT jobjectArray JNICALL native_get_ips(JNIEnv *env, jobject thisObj, jobject c, jstring interface, jstring family, jint scope) {
    const char *interfaceStr = (*env)->GetStringUTFChars(env, interface, NULL);
    const char *familyStr = (*env)->GetStringUTFChars(env, family, NULL);
    char **ips = jni_lxc_get_ips((struct lxc_container*)c, interfaceStr, familyStr, scope);
    (*env)->ReleaseStringUTFChars(env, interface, interfaceStr);
    (*env)->ReleaseStringUTFChars(env, family, familyStr);

    if (ips == NULL) {
        return NULL;
    }

    // Counting the number of IPs
    int i = 0;
    while (ips[i] != NULL) {
        i++;
    }

    // Create a new Java String array of the correct size
    jobjectArray result = (*env)->NewObjectArray(env, i, (*env)->FindClass(env, "java/lang/String"), NULL);

    // Populate the Java String array
    for (int j = 0; j < i; j++) {
        (*env)->SetObjectArrayElement(env, result, j, (*env)->NewStringUTF(env, ips[j]));
    }

    return result;
}

JNIEXPORT jstring JNICALL native_get_keys(JNIEnv *env, jobject thisObj, jobject c, jstring key) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    char *value = jni_lxc_get_keys((struct lxc_container*)c, keyStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    if (value == NULL) {
        return NULL;
    }
    return (*env)->NewStringUTF(env, value);
}

JNIEXPORT jstring JNICALL native_get_running_config_item(JNIEnv *env, jobject thisObj, jobject c, jstring key) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    char *value = jni_lxc_get_running_config_item((struct lxc_container*)c, keyStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    if (value == NULL) {
        return NULL;
    }
    return (*env)->NewStringUTF(env, value);
}

JNIEXPORT jstring JNICALL native_get_config_path(JNIEnv *env, jobject thisObj, jobject c) {
    const char *path = jni_lxc_get_config_path((struct lxc_container*)c);
    if (path == NULL) {
        return NULL;
    }
    return (*env)->NewStringUTF(env, path);
}

JNIEXPORT jstring JNICALL native_state(JNIEnv *env, jobject thisObj, jobject c) {
    const char *state = jni_lxc_state((struct lxc_container*)c);
    if (state == NULL) {
        return NULL;
    }
    return (*env)->NewStringUTF(env, state);
}

JNIEXPORT jint JNICALL native_attach_run_wait(JNIEnv *env, jobject thisObj, jobject c, jboolean clear_env, jint namespaces, jlong personality, jint uid, jint gid, jintArray groups, jint stdinfd, jint stdoutfd, jint stderrfd, jstring initial_cwd, jobjectArray extra_env_vars, jobjectArray extra_keep_env, jobjectArray argv, jint attach_flags) {
    jint *groupsArray = NULL;
    size_t groupsLength = 0;

    if (groups != NULL) {
        groupsLength = (*env)->GetArrayLength(env, groups);  // Get the length of the groups array
        groupsArray = (*env)->GetIntArrayElements(env, groups, NULL);  // Get the elements of the jintArray
    }

    // Allocate and populate the lxc_groups_t structure
    lxc_groups_t lxcGroups;
    lxcGroups.size = groupsLength;

    // Dynamically allocate memory for the gid_t list
    gid_t *gidList = (gid_t *)malloc(groupsLength * sizeof(gid_t));
    for (size_t i = 0; i < groupsLength; i++) {
        gidList[i] = (gid_t)groupsArray[i];  // Convert jint to gid_t and store in the list
    }

    lxcGroups.list = gidList;

    const char *cwdStr = (*env)->GetStringUTFChars(env, initial_cwd, NULL);
    char **envVars = jni_string_array_to_c_type(env, extra_env_vars);
    char **keepEnv = jni_string_array_to_c_type(env, extra_keep_env);
    char **argvArray = jni_string_array_to_c_type(env, argv);

    int result = jni_lxc_attach_run_wait((struct lxc_container*)c, clear_env, namespaces, personality, uid, gid, lxcGroups, stdinfd, stdoutfd, stderrfd, cwdStr, envVars, keepEnv, argvArray, attach_flags);

    // Release Java string arrays and memory
    if (groups != NULL) {
        (*env)->ReleaseIntArrayElements(env, groups, groupsArray, 0);  // Release the jintArray
    }
    if (initial_cwd != NULL) {
        (*env)->ReleaseStringUTFChars(env, initial_cwd, cwdStr);  // Release the Java string
    }

    freeCStringArray(envVars);
    freeCStringArray(keepEnv);
    freeCStringArray(argvArray);

    free(gidList);

    return result;
}

JNIEXPORT jint JNICALL native_attach(JNIEnv *env, jobject thisObj, jobject c, jboolean clear_env, jint namespaces, jlong personality, jint uid, jint gid, jintArray groups, jint stdinfd, jint stdoutfd, jint stderrfd, jstring initial_cwd, jobjectArray extra_env_vars, jobjectArray extra_keep_env, jint attach_flags) {
    jint *groupsArray = NULL;
    size_t groupsLength = 0;

    if (groups != NULL) {
        groupsLength = (*env)->GetArrayLength(env, groups);  // Get the length of the groups array
        groupsArray = (*env)->GetIntArrayElements(env, groups, NULL);  // Get the elements of the jintArray
    }

    // Allocate and populate the lxc_groups_t structure
    lxc_groups_t lxcGroups;
    lxcGroups.size = groupsLength;

    // Dynamically allocate memory for the gid_t list
    gid_t *gidList = (gid_t *)malloc(groupsLength * sizeof(gid_t));
    for (size_t i = 0; i < groupsLength; i++) {
        gidList[i] = (gid_t)groupsArray[i];  // Convert jint to gid_t and store in the list
    }

    lxcGroups.list = gidList;

    const char *cwdStr = (*env)->GetStringUTFChars(env, initial_cwd, NULL);
    char **envVars = jni_string_array_to_c_type(env, extra_env_vars);
    char **keepEnv = jni_string_array_to_c_type(env, extra_keep_env);

    int result = jni_lxc_attach((struct lxc_container*)c, clear_env, namespaces, personality, uid, gid, lxcGroups, stdinfd, stdoutfd, stderrfd, cwdStr, envVars, keepEnv, attach_flags);

    if (groups != NULL) {
        (*env)->ReleaseIntArrayElements(env, groups, groupsArray, 0);
    }
    if (initial_cwd != NULL) {
        (*env)->ReleaseStringUTFChars(env, initial_cwd, cwdStr);
    }

    freeCStringArray(envVars);
    freeCStringArray(keepEnv);
	free(gidList);

    return result;
}

JNIEXPORT jint JNICALL native_attach_no_wait(JNIEnv *env, jobject thisObj, jobject c, jboolean clear_env, jint namespaces, jlong personality, jint uid, jint gid, jintArray groups, jint stdinfd, jint stdoutfd, jint stderrfd, jstring initial_cwd, jobjectArray extra_env_vars, jobjectArray extra_keep_env, jobjectArray argv, jobject attached_pid, jint attach_flags) {
    jint *groupsArray = NULL;
    size_t groupsLength = 0;

    if (groups != NULL) {
        groupsLength = (*env)->GetArrayLength(env, groups);  // Get the length of the groups array
        groupsArray = (*env)->GetIntArrayElements(env, groups, NULL);  // Get the elements of the jintArray
    }

    // Allocate and populate the lxc_groups_t structure
    lxc_groups_t lxcGroups;
    lxcGroups.size = groupsLength;

    // Dynamically allocate memory for the gid_t list
    gid_t *gidList = (gid_t *)malloc(groupsLength * sizeof(gid_t));
    for (size_t i = 0; i < groupsLength; i++) {
        gidList[i] = (gid_t)groupsArray[i];  // Convert jint to gid_t and store in the list
    }

    lxcGroups.list = gidList;

    const char *cwdStr = (*env)->GetStringUTFChars(env, initial_cwd, NULL);
    char **envVars = jni_string_array_to_c_type(env, extra_env_vars);
    char **keepEnv = jni_string_array_to_c_type(env, extra_keep_env);
    const char **argvArray = jni_string_array_to_c_type(env, argv);

	pid_t *pid = NULL;
	if (attached_pid != NULL) {
    	jint pidInt = (*env)->GetIntField(env, attached_pid, 
                                    (*env)->GetFieldID(env, 
                                    (*env)->GetObjectClass(env, attached_pid), 
                                	"value", "I"));
    	pid = malloc(sizeof(pid_t));
    	if (pid != NULL)
        	*pid = (pid_t)pidInt;
	}

    int result = jni_lxc_attach_no_wait((struct lxc_container*)c, clear_env, namespaces, personality, uid, gid, lxcGroups, stdinfd, stdoutfd, stderrfd, cwdStr, envVars, keepEnv, argvArray, pid, attach_flags);

    if (groups != NULL) {
        (*env)->ReleaseIntArrayElements(env, groups, groupsArray, 0);
    }
    if (initial_cwd != NULL) {
        (*env)->ReleaseStringUTFChars(env, initial_cwd, cwdStr);
    }

    freeCStringArray(envVars);
    freeCStringArray(keepEnv);
    freeCStringArray(argvArray);
	free(gidList);

    return result;
}

JNIEXPORT jint JNICALL native_console_getfd(JNIEnv *env, jobject thisObj, jobject c, jint ttynum) {
    return jni_lxc_console_getfd((struct lxc_container*)c, ttynum);
}

JNIEXPORT jint JNICALL native_snapshot_list(JNIEnv *env, jobject thisObj, jobject c) {
    struct lxc_snapshot *snapshotList = NULL;
    int result = jni_lxc_snapshot_list((struct lxc_container*)c, &snapshotList);
    return result;
}

JNIEXPORT jint JNICALL native_snapshot(JNIEnv *env, jobject thisObj, jobject c) {
    return jni_lxc_snapshot((struct lxc_container*)c);
}

JNIEXPORT jint JNICALL native_init_pid(JNIEnv *env, jobject thisObj, jobject c) {
    pid_t pid = jni_lxc_init_pid((struct lxc_container*)c);
    return (jint)pid;
}

JNIEXPORT jint JNICALL native_init_pidfd(JNIEnv *env, jobject thisObj, jobject c) {
    return jni_lxc_init_pidfd((struct lxc_container*)c);
}

JNIEXPORT jint JNICALL native_devpts_fd(JNIEnv *env, jobject thisObj, jobject c) {
    return jni_lxc_devpts_fd((struct lxc_container*)c);
}

JNIEXPORT jint JNICALL native_seccomp_notify_fd(JNIEnv *env, jobject thisObj, jobject c) {
    return jni_lxc_seccomp_notify_fd((struct lxc_container*)c);
}

JNIEXPORT jint JNICALL native_seccomp_notify_fd_active(JNIEnv *env, jobject thisObj, jobject c) {
    return jni_lxc_seccomp_notify_fd_active((struct lxc_container*)c);
}

JNIEXPORT jint JNICALL native_set_timeout(JNIEnv *env, jobject thisObj, jobject c, jint timeout) {
    return jni_lxc_set_timeout((struct lxc_container*)c, timeout);
}

JNIEXPORT jboolean JNICALL native_checkpoint(JNIEnv *env, jobject thisObj, jobject c, jstring directory, jboolean stop, jboolean verbose) {
    const char *dir = (*env)->GetStringUTFChars(env, directory, NULL);
    bool result = jni_lxc_checkpoint((struct lxc_container*)c, (char*)dir, stop, verbose);
    (*env)->ReleaseStringUTFChars(env, directory, dir);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL native_restore(JNIEnv *env, jobject thisObj, jobject c, jstring directory, jboolean verbose) {
    const char *dir = (*env)->GetStringUTFChars(env, directory, NULL);
    bool result = jni_lxc_restore((struct lxc_container*)c, (char*)dir, verbose);
    (*env)->ReleaseStringUTFChars(env, directory, dir);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL native_config_item_is_supported(JNIEnv *env, jobject thisObj, jstring key) {
    const char *keyStr = (*env)->GetStringUTFChars(env, key, NULL);
    bool result = jni_lxc_config_item_is_supported(keyStr);
    (*env)->ReleaseStringUTFChars(env, key, keyStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL native_has_api_extension(JNIEnv *env, jobject thisObj, jstring extension) {
    const char *extStr = (*env)->GetStringUTFChars(env, extension, NULL);
    bool result = jni_lxc_has_api_extension(extStr);
	(*env)->ReleaseStringUTFChars(env, extension, extStr);
	return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL native_attach_interface(JNIEnv *env, jobject thisObj, jobject c, jstring dev, jstring dst_dev) {
    const char *devStr = (*env)->GetStringUTFChars(env, dev, NULL);
    const char *dstDevStr = (*env)->GetStringUTFChars(env, dst_dev, NULL);
    bool result = jni_lxc_attach_interface((struct lxc_container*)c, devStr, dstDevStr);
    (*env)->ReleaseStringUTFChars(env, dev, devStr);
    (*env)->ReleaseStringUTFChars(env, dst_dev, dstDevStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL native_detach_interface(JNIEnv *env, jobject thisObj, jobject c, jstring dev, jstring dst_dev) {
    const char *devStr = (*env)->GetStringUTFChars(env, dev, NULL);
    const char *dstDevStr = (*env)->GetStringUTFChars(env, dst_dev, NULL);
    bool result = jni_lxc_detach_interface((struct lxc_container*)c, devStr, dstDevStr);
    (*env)->ReleaseStringUTFChars(env, dev, devStr);
    (*env)->ReleaseStringUTFChars(env, dst_dev, dstDevStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL native_console_log(JNIEnv *env, jobject thisObj, jobject c, jobject log) {
    struct lxc_console_log *consoleLog = (struct lxc_console_log*)(*env)->GetDirectBufferAddress(env, log);
    int result = jni_lxc_console_log((struct lxc_container*)c, consoleLog);
    return result;
}

JNIEXPORT jint JNICALL native_error_num(JNIEnv *env, jobject thisObj, jobject c) {
    return jni_lxc_error_num((struct lxc_container*)c);
}

static JNINativeMethod method_table[] = {
    {"getVersion", "()Ljava/lang/String;", (void *)native_getVersion},
	{"addDeviceNode", "()Ljava/lang/Boolean;", (void *)native_add_device_node}
};

static int register_native_methods(JNIEnv *env, const char *class_name, 
                                  JNINativeMethod *methods, int num_methods) {
    jclass clazz = (*env)->FindClass(env, class_name);
    if (clazz == NULL) {
        return JNI_FALSE;
    }
    
    if ((*env)->RegisterNatives(env, clazz, methods, num_methods) < 0) {
        return JNI_FALSE;
    }
    
    return JNI_TRUE;
}

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env = NULL;
    jint result = -1;
    
    if ((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        return result;
    }
    
    const char *class_name = "io/github/coap/lxc/LxcNative";
    int num_methods = sizeof(method_table) / sizeof(method_table[0]);
    
    if (!register_native_methods(env, class_name, method_table, num_methods)) {
        return result;
    }
    
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNI_OnUnload(JavaVM *vm, void *reserved) {
}

char** jni_string_array_to_c_type(JNIEnv *env, jobjectArray javaArray) {
    if (javaArray == NULL) return NULL;

    jsize arrayLength = (*env)->GetArrayLength(env, javaArray);
    char **cArray = (char**)malloc(sizeof(char*) * (arrayLength + 1));  // +1 用于 NULL 终止符

    for (int i = 0; i < arrayLength; i++) {
        jstring javaString = (jstring)(*env)->GetObjectArrayElement(env, javaArray, i);
        const char* cStr = (*env)->GetStringUTFChars(env, javaString, NULL);
        cArray[i] = strdup(cStr);  // 使用 strdup 来复制字符串，避免内存问题
        (*env)->ReleaseStringUTFChars(env, javaString, cStr);
    }

    cArray[arrayLength] = NULL;  // NULL 终止数组
    return cArray;
}

static void freeCStringArray(char **array) {
    if (array != NULL) {
        for (int i = 0; array[i] != NULL; i++) {
            free(array[i]);  // 释放每个字符串
        }
        free(array);  // 释放数组本身
    }
}
