#ifndef LXC_WRAPPER_H
#define LXC_WRAPPER_H

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved);
JNIEXPORT void JNI_OnUnload(JavaVM *vm, void *reserved);

JNIEXPORT jstring JNICALL native_getVersion(JNIEnv *env, jobject thisObj);

char **jni_string_array_to_c_type(JNIEnv *env, jobjectArray javaArray);
static void freeCStringArray(char**);

#ifdef __cplusplus
}
#endif

#endif // LXC_WRAPPER_H
